<?php
if(isset($_GET['ID'])){
    $id_task = $_GET['ID'];
echo $id_task;
}
else{
    echo 'toto';
}


 ?>       
        
